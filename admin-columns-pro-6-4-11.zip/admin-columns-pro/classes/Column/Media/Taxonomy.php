<?php

namespace ACP\Column\Media;

use ACP;

class Taxonomy extends ACP\Column\Post\Taxonomy {

}