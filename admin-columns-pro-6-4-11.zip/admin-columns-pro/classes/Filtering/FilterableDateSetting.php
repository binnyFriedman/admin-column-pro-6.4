<?php

namespace ACP\Filtering;

interface FilterableDateSetting
{

    public function get_filtering_date_setting(): ?string;

}