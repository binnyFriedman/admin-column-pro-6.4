<?php

namespace ACP\Filtering\Model\Post;

use ACP\Search;

/**
 * @deprecated NEWVERSION
 */
class Content extends Search\Comparison\Post\Content
{

}