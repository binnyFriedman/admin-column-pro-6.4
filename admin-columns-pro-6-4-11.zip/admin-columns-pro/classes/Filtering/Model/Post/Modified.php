<?php

namespace ACP\Filtering\Model\Post;

/**
 * @deprecated NEWVERSION
 */
class Modified extends Date
{

    public function __construct($column)
    {
        parent::__construct($column);
    }

}