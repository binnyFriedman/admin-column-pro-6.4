<?php

declare(strict_types=1);

namespace ACP\Filtering;

interface EmptyOptions
{

    public const IS_EMPTY = 'cpac_empty';
    public const NOT_IS_EMPTY = 'cpac_nonempty';

}